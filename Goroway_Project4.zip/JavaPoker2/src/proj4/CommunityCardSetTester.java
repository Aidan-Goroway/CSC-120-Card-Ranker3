package proj4;

import java.util.ArrayList;

public class CommunityCardSetTester {

    public static void main(String[] args) {

        Testing.startTests();
        testToString();
        testAddCard();
        testGetIthCard();
        Testing.finishTests();
    }

    public static void testToString(){
        Card c1 = new Card("11","Hearts");
        Card c2 = new Card("7","Hearts");
        Card c3 = new Card("14","Hearts");
        Card c4 = new Card("9","Diamonds");
        Card c5 = new Card("3","Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Testing.assertEquals("Tests for communitycardsets toString"
                , "[Jack of Hearts, 7 of Hearts, Ace of Hearts, 9 of Diamonds, 3 of Hearts]"
                , hand1.toString());
    }

    public static void testAddCard(){
        Card d1 = new Card(2,0);
        Card d2 = new Card(12,3);
        Card d3 = new Card(10,2);
        Card d4 = new Card(9,1);
        Card d5 = new Card(13,3);
        ArrayList<Card> array2 = new ArrayList<>();
        PokerHand hand2 = new PokerHand(array2);
        hand2.addCard(d1);
        hand2.addCard(d2);
        hand2.addCard(d3);
        hand2.addCard(d4);
        hand2.addCard(d5);

        Testing.assertEquals("Tests 2 flushes for the 2nd highest card"
                , "[2 of Spades, Queen of Diamonds, 10 of Clubs, 9 of Hearts, King of Diamonds]"
                , hand2.toString());
    }

    public static void testGetIthCard(){
        Card c1 = new Card("10","Hearts");
        Card c2 = new Card("10","Diamonds");
        Card c3 = new Card("8","Hearts");
        Card c4 = new Card("8","Hearts");
        Card c5 = new Card("3","Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Testing.assertEquals("Tests getIthCard for the 2nd indexed card of the pokerhand"
                , "8 of Hearts"
                , hand1.get_ith_card(2));
    }
}
