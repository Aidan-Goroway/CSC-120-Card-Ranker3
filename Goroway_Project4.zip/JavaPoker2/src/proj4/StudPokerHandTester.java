package proj4;

import java.util.ArrayList;

public class StudPokerHandTester {

    public static void main(String[] args) {
        Testing.startTests();
        testToString();
        testAddCard();
        testGetIthCard();
        Testing.finishTests();
    }

    public static void testToString(){
        Card c1 = new Card("11","Hearts");
        Card c2 = new Card("7","Hearts");
        Card c3 = new Card("14","Hearts");
        Card c4 = new Card("9","Diamonds");
        Card c5 = new Card("3","Hearts");

        Card d1 = new Card(14,3);
        Card d2 = new Card(12,3);

        ArrayList<Card> array1 = new ArrayList<>();
        CommunityCardSet cCards = new CommunityCardSet(array1);
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);

        StudPokerHand hand2 = new StudPokerHand(cCards, array2);

        Testing.assertEquals("Tests toString of the stud"
                , "[Ace of Diamonds, Queen of Diamonds]"
                , hand2.toString());
    }

    public static void testAddCard(){
        Card c1 = new Card("11","Hearts");
        Card c2 = new Card("7","Hearts");
        Card c3 = new Card("14","Hearts");
        Card c4 = new Card("9","Diamonds");
        Card c5 = new Card("3","Hearts");

        Card d1 = new Card(4,0);
        Card d2 = new Card(11,2);

        ArrayList<Card> array1 = new ArrayList<>();
        CommunityCardSet cCards = new CommunityCardSet(array1);
        ArrayList<Card> array2 = new ArrayList<>();

        StudPokerHand hand2 = new StudPokerHand(cCards, array2);
        hand2.addCard(d1);
        hand2.addCard(d2);

        Testing.assertEquals("Tests addCard of the stud"
                , "[4 of Spades, Jack of Clubs]"
                , hand2.toString());
    }

    public static void testGetIthCard(){
        Card c1 = new Card("11","Hearts");
        Card c2 = new Card("7","Hearts");
        Card c3 = new Card("14","Hearts");
        Card c4 = new Card("9","Diamonds");
        Card c5 = new Card("3","Hearts");

        Card d1 = new Card(14,3);
        Card d2 = new Card(12,3);

        ArrayList<Card> array1 = new ArrayList<>();
        CommunityCardSet cCards = new CommunityCardSet(array1);
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);

        StudPokerHand hand2 = new StudPokerHand(cCards, array2);

        Testing.assertEquals("Tests getIthCard of the stud"
                , "Queen of Diamonds"
                , hand2.get_ith_card(1));
    }

}
