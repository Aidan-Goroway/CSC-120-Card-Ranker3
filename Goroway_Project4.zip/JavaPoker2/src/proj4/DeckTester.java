package proj4;

public class DeckTester {

    //Deck is constructed by INTS RANK 2-14, SUIT 0-3 for each.
    // Alternatively, you can use STRINGS "#" and "suit"
    public static void main(String[] args) {
        Testing.startTests();
        testToString();
        testToStringLast3();
        testShuffle();
        testIsEmpty();
        testGather();
        testSize();
        Testing.finishTests();
    }

    public static void testToString(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 0;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }
        Testing.assertEquals("Tests a printout of the entire deck"
                ,"The entire deck, Spades->Clubs->Hearts->Diamonds for ranks 2-Ace"
                , deck1.toString());
    }

    public static void testToStringLast3(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 49;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }
        Testing.assertEquals("Tests a printout of the last 3 cards of the deck"
                ,"[Ace of Hearts, Ace of Clubs, Ace of Diamonds]"
                , deck1.toString());
    }

    public static void testShuffle(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 0;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }
        deck1.shuffle();
        Testing.assertEquals("Tests a printout of the entire deck, shuffled"
                ,"52 cards in random order"
                , deck1.toString());
    }

    public static void testIsEmpty(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 52;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }
        Testing.assertEquals("Tests if the deck is empty"
                ,true
                , deck1.isEmpty());
    }

    public static void testGather(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 52;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }

        deck1.gather();

        Testing.assertEquals("Tests if the deck is refilled"
                ,false
                , deck1.isEmpty());
    }

    public static void testSize(){
        Deck deck1 = new Deck();
        final int CARDS_TO_SKIP = 30;
        for (int x = 0; x<CARDS_TO_SKIP; x++){
            deck1.deal();
        }
        Testing.assertEquals("Tests the deck's remaining cards"
                ,22
                , deck1.size());
    }

}
