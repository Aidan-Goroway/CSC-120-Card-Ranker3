package proj4;

public class CardTester {
    public static void main(String[] args) {
        Testing.startTests();
        testToStringINT();
        testToStringSTR();
        testGetRank1();
        testGetRank2();
        testGetSuit1();
        testGetSuit2();
        Testing.finishTests();
    }

    public static void testToStringINT(){
        Card kingDiamond = new Card(12,3);

        Testing.assertEquals("Tests toString for a Queen of diamonds (INT)"
        , "Queen of Diamonds"
        , kingDiamond.toString());
    }

    public static void testToStringSTR(){
        Card threeDiamond = new Card("3","Clubs");

        Testing.assertEquals("Tests toString for a 3 of Clubs (STR)"
                , "3 of Clubs"
                , threeDiamond.toString());
    }

    public static void testGetRank1(){
        Card threeDiamond = new Card("three","diamonds");

        Testing.assertEquals("Tests toString for the rank of a 3 of diamonds(STR)"
                , 3
                , threeDiamond.getRank());
    }

    public static void testGetRank2(){
        Card threeDiamond = new Card("jack","Spades");

        Testing.assertEquals("Tests toString for the rank of a Jack of Spades(STR)"
                , 11
                , threeDiamond.getRank());
    }

    public static void testGetSuit1(){
        Card eightClubs = new Card(8,2);

        Testing.assertEquals("Tests toString for the suit of an Eight of Clubs(STR)"
                , "Clubs"
                , eightClubs.getSuit());
    }

    public static void testGetSuit2(){
        Card eightClubs = new Card(14,1);

        Testing.assertEquals("Tests toString for the suit of an Ace of Hearts(STR)"
                , "Hearts"
                , eightClubs.getSuit());
    }
}
