package proj4;

public class Card {

    private int rank;
    private int suit;

    private final String[] strNumRanks = {"fillerIndex0", "fillerIndex1", "2", "3", "4", "5",
            "6", "7", "8", "9", "10", "11", "12", "13", "14"};
    private final String[] strStringRanks = {"fillerIndex0", "fillerIndex1", "Two", "Three", "Four", "Five",
            "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen"};
    private final String[] strUpperRanks = {"fillerIndex0", "fillerIndex1", "Two", "Three", "Four", "Five",
            "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace"};

    private final String[] strStringSuits = {"Spades", "Hearts", "Clubs", "Diamonds"};

    /**
     * constructor
     * @param rank String: whole cards (2-10) can either be spelled
     * out like "two" or numeric like "2". Case insensitive.
     * @param suit String: "Spades", "Hearts", "Clubs", or "Diamonds"
     */
    public Card(String rank, String suit){

        this.rank = rankString2rankInt(rank);
        this.suit = suitString2suitInt(suit);

    }

    /**
     * constructor
     * @param rank integer between 2-14
     * @param suit integer: 0=Spades, 1=Hearts, 2=Clubs, or 3=Diamonds
     */
    public Card(int rank, int suit){

        this.rank = rank;
        this.suit = suit;

    }


    /**
     * Converts a String rank to an integer.
     * @param rank2convert The rank we are converting to an integer.
     * @return The int the rank represents
     */
    private int rankString2rankInt(String rank2convert){

        for (int index = 2; index < strNumRanks.length; index++) {
            if ((rank2convert.equalsIgnoreCase(strNumRanks[index])) ||
                    (rank2convert.equalsIgnoreCase(strStringRanks[index])) ||
                    (rank2convert.equalsIgnoreCase(strUpperRanks[index])))
                        {
                        return index;
                        }
        }
        return 999; // will not go off, here for syntax purposes
    }

    /**
     * Converts a String suit to an integer.
     * @param suit2convert The suit we are converting to an integer.
     * @return The int the suit represents
     */
    private int suitString2suitInt(String suit2convert) {

        for (int index = 0; index < strStringSuits.length; index++){
            if (suit2convert.equalsIgnoreCase(strStringSuits[index])){
                return index;
            }
        }
        return 999; // will not go off, here for syntax purposes
    }

    /**
     * getter for rank
     * @return card's rank as integer: 2-14
     */
    public int getRank() {
        return rank;
    }



    /**
     * getter for suit
     * @return string (plural, starts with Capital letter)
     */
    public String getSuit() {
        for (int index = 0; index < strStringSuits.length; index++){
            if (Integer.toString(suit).equals(Integer.toString(index))){
                return strStringSuits[index];
            }
        }
        return "Error"; // will not go off, Here for syntax purposes
    }

    /**
     * Uses getRank() to get an int Rank, then converts it back into a String.
     * @return A stringified version of the int Rank.
     */
    private String rank2String(){
        int myRank = getRank();
        if (myRank == 11) {
            return "Jack";
        }
        else if (myRank == 12) {
            return "Queen";
        }
        else if (myRank == 13) {
            return "King";
        }
        else if (myRank == 14) {
            return "Ace";
        }
        else {  // must be a whole number - just convert it to string
            return "" + myRank;
        }
    }

    /**
     * returns string version of Card
     * @return string like "Jack of Clubs"
     */
    public String toString() {
        return  rank2String() + " of " + getSuit();
    }

}
