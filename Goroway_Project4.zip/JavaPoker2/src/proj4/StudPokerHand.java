package proj4;

import java.util.ArrayList;

public class StudPokerHand {

    private final int MAX_CARDS_IN_STUD = 2;
    private final int MAX_CARDS_IN_HAND = 5;

    private ArrayList<Card> cardList;
    private CommunityCardSet cCards;

    /**
     * Constructor.
     * @param cc The set of Community Cards currently in play.
     * @param cardList the StudPokerHand we are constructing.
     */
    public StudPokerHand(CommunityCardSet cc, ArrayList<Card> cardList){
        this.cardList = cardList;
        this.cCards = cc;
    }

    /**
     * Adds a card to the StudHand.
     * If the hand is full, does nothing.
     * @param CardObject The card that will be added.
     */
    public void addCard(Card CardObject){
        if (cardList.size() <= MAX_CARDS_IN_STUD){
            cardList.add(CardObject);
        }
        else {
            return;
        }
    }

    /**
     * Returns a card from the Stud.
     * @param index The index of the card we are getting.
     * @return returns the card at the specified index.
     * If the index is invalid, returns nothing at all.
     */
    public Card get_ith_card(int index){

        if ((index >= 0) || (index < MAX_CARDS_IN_STUD)){
            return cardList.get(index);
        }
        else {
            return null;
        }
    }

    /**
     * Returns all the cards in the Stud.
     * @return Returns an easily readable string of all the cards in the Stud.
     */
    public String toString(){

        ArrayList<Card> studList = new ArrayList<>();
        for (int card=0; card<cardList.size(); card++){
            studList.add( cardList.get(card) );
        }
        String studCards = studList.toString();
        return studCards;
    }

    /**
     * Determines how this hand compares to another hand, using the
     * community card set to determine the best 5-card hand it can
     * make. Returns positive, negative, or zero depending on the comparison.
     *
     * @param other The hand to compare this hand to
     * @return a negative number if this is worth LESS than other, zero
     * if they are worth the SAME, and a positive number if this is worth
     * MORE than other
     */
    public int compareTo(StudPokerHand other){

        PokerHand hand1 = this.getBestFiveCardHand();
        PokerHand hand2 = other.getBestFiveCardHand();

        return hand1.compareTo(hand2);

    }

    /**
     * Determines every possible hand that can be created from a stud and the
     * available community cards, and returns a list of them.
     * @return An ArrayList of all Pokerhands made from the 7 cards available.
     */
    private ArrayList<PokerHand> getAllFiveCardHands(){
        ArrayList<PokerHand> handList = new ArrayList<>();

        for (int i = 0; i < 6; i++){ // elimination loop
            for (int j = (i + 1); j < 6; j++){

                ArrayList<Card> sevenList = new ArrayList<>(); //our seven cards

                for (int index = 0; index < MAX_CARDS_IN_HAND; index++){
                    sevenList.add(cCards.get_ith_card(index));
                }
                for (int index = 0; index < MAX_CARDS_IN_STUD; index++){
                    sevenList.add(cardList.get(index));
                }
                sevenList.remove(j);
                sevenList.remove(i);
                PokerHand fiveList = new PokerHand(sevenList);
                handList.add(fiveList);
            }
        }
        return handList; // contains 21 combinations
    }

    /**
     * Determines the best possible hand that can be made.
     * @return The best possible hand that can be created from a stud and
     * the available community cards.
     */
    private PokerHand getBestFiveCardHand()
    {
        ArrayList<PokerHand> hands = getAllFiveCardHands();
        PokerHand bestSoFar = hands.get(0);
        for (int i = 1; i < hands.size(); i++) {
            if (hands.get(i).compareTo(bestSoFar) > 0) {
                bestSoFar = hands.get(i);
            }
        }
        return bestSoFar;
    }

}
