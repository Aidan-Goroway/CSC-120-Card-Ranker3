package proj4;

/*
I affirm that I have carried out the attached academic endeavors with full academic honesty, in
accordance with the Union College Honor Code and the course syllabus.
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) {

        final int MAX_CARDS_IN_HAND = 5;
        final int MAX_CARDS_IN_COMSET = 5;
        final int MAX_CARDS_IN_STUD = 2;
        int points = 0;
        String messageLoss = "Incorrect. Final points: "; // +  points;
        String messageWin = "You win! Final points: "; //+ points;

        Deck newDeck = new Deck();
        newDeck.shuffle(); // create and shuffle deck

        ArrayList<Card> communityArray = new ArrayList<>(); // create community cards
        CommunityCardSet cardSet = new CommunityCardSet(communityArray);

        ArrayList<Card> h1 = new ArrayList<>(); // create studs
        StudPokerHand stud1 = new StudPokerHand(cardSet, h1);
        ArrayList<Card> h2 = new ArrayList<>();
        StudPokerHand stud2 = new StudPokerHand(cardSet, h2);

        for (int comToDeal = 0; comToDeal < MAX_CARDS_IN_COMSET; comToDeal++){ // community dealing loop
            Card card = newDeck.deal();
            cardSet.addCard(card);
        }

        while (newDeck.size() > (MAX_CARDS_IN_STUD * 2)){

            for (int cardToDeal = 0; cardToDeal < MAX_CARDS_IN_STUD; cardToDeal++){ // stud dealing loop
                Card card1 = newDeck.deal();
                stud1.addCard(card1);

                Card card2 = newDeck.deal();
                stud2.addCard(card2);
            }

            int answer = stud1.compareTo(stud2);

            System.out.println();
            System.out.println("Which of the two studs can create a more valuable hand?");
            System.out.println();
            System.out.println("Community Cards: " + cardSet);
            System.out.println("Stud 1: " + stud1); // ask teach about redundant printing
//            System.out.println();
            System.out.println("Stud 2: " + stud2); //
            System.out.println();
            System.out.println("Answer \"1\" for Stud 1, or \"-1\" for Stud 2, or \"0\" if there is a tie.");
            Scanner scan = new Scanner(System.in);
            int guess = scan.nextInt();

            if (answer == guess) {
                points++;
                System.out.println("Correct!");
            } else {
                System.out.println(messageLoss + points);
                System.out.println("The answer was: " + answer);
                return;
            }

            h1.clear();
            h2.clear();
        }

        System.out.println(messageWin + points);

    }
}
