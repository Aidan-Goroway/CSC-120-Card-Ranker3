package proj4;

/*
I affirm that I have carried out the attached academic endeavors with full academic honesty, in
accordance with the Union College Honor Code and the course syllabus.
 */

import java.util.ArrayList;

public class PokerHandTester {

    public static void main(String[] args) {
        //calls go here
        //CHECK VERBOSITY BOOLEAN IN TESTING//

        Testing.startTests();
        testCompareToHC1();
        testCompareTo2Flushes1();
        testCompareTo2Pairs1();
        testCompareTo2TwoPairs1();
        testCompareTo2Pairs2();
        testCompareTo2twoPairs2();
        testGetIthCard();
        testToString();
        testAddCard();
        Testing.finishTests();

    }
    //methods go here

    public static void testCompareToHC1(){
        Card c1 = new Card("11","Hearts");
        Card c2 = new Card("7","Hearts");
        Card c3 = new Card("14","Hearts");
        Card c4 = new Card("9","Diamonds");
        Card c5 = new Card("3","Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(8,0);
        Card d2 = new Card(7,3);
        Card d3 = new Card(13,3);
        Card d4 = new Card(12,3);
        Card d5 = new Card(9,3);
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests for 2 highCards"
                , 1
                , hand1.compareTo(hand2));
    }

    public static void testCompareTo2Flushes1(){
        Card c1 = new Card("14","Hearts");
        Card c2 = new Card("12","Hearts");
        Card c3 = new Card("12","Hearts");
        Card c4 = new Card("11","Hearts");
        Card c5 = new Card("7","Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(14,3);
        Card d2 = new Card(12,3);
        Card d3 = new Card(9,3);
        Card d4 = new Card(9,3);
        Card d5 = new Card(13,3);
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests 2 flushes for the 2nd highest card"
                , -1
                , hand1.compareTo(hand2));
    }


    public static void testCompareTo2Pairs1(){
        Card c1 = new Card(12,2);
        Card c2 = new Card(12,3);
        Card c3 = new Card(6,2);
        Card c4 = new Card(5,2);
        Card c5 = new Card(3,2);
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card("11","Hearts");
        Card d2 = new Card("11","Diamonds");
        Card d3 = new Card("9","Diamonds");
        Card d4 = new Card("8","Diamonds");
        Card d5 = new Card("7","Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests CompareTo for a pair of queens vs a pair of jacks"
                , 1
                , hand1.compareTo(hand2));
    }

    public static void testCompareTo2TwoPairs1(){
        Card c1 = new Card("10","Hearts");
        Card c2 = new Card("10","Diamonds");
        Card c3 = new Card("8","Hearts");
        Card c4 = new Card("8","Hearts");
        Card c5 = new Card("3","Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card("10","Hearts");
        Card d2 = new Card("10","Diamonds");
        Card d3 = new Card("6","Diamonds");
        Card d4 = new Card("6","Diamonds");
        Card d5 = new Card("7","Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests CompareTo for a twopair of 10s vs a twopair of 8s"
                , 1
                , hand1.compareTo(hand2));
    }

    public static void testCompareTo2Pairs2(){
        Card c1 = new Card(10,2);
        Card c2 = new Card(10,3);
        Card c3 = new Card(13,2);
        Card c4 = new Card(8,2);
        Card c5 = new Card(3,2);
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card(10,2);
        Card d2 = new Card(10,3);
        Card d3 = new Card(11,3);
        Card d4 = new Card(6,3);
        Card d5 = new Card(7,3);
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests for 2 pairs that break tie with their first chaser"
                , 1
                , hand1.compareTo(hand2));
    }

    public static void testCompareTo2twoPairs2(){
        Card c1 = new Card("14","Hearts");
        Card c2 = new Card("14","Diamonds");
        Card c3 = new Card("7","Hearts");
        Card c4 = new Card("7","Hearts");
        Card c5 = new Card("3","Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Card d1 = new Card("14","Spades");
        Card d2 = new Card("14","Clubs");
        Card d3 = new Card("7","Diamonds");
        Card d4 = new Card("7","Diamonds");
        Card d5 = new Card("7","Diamonds");
        ArrayList<Card> array2 = new ArrayList<>();
        array2.add(d1);
        array2.add(d2);
        array2.add(d3);
        array2.add(d4);
        array2.add(d5);
        PokerHand hand2 = new PokerHand(array2);

        Testing.assertEquals("Tests for 2 twoPairs that break tie with their last chaser"
                , -1
                , hand1.compareTo(hand2));
    }

    public static void testGetIthCard(){
        Card c1 = new Card("10","Hearts");
        Card c2 = new Card("10","Diamonds");
        Card c3 = new Card("8","Hearts");
        Card c4 = new Card("8","Hearts");
        Card c5 = new Card("3","Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Testing.assertEquals("Tests getIthCard for the 2nd indexed card of the pokerhand"
                , "8 of Hearts"
                , hand1.get_ith_card(2));
    }

    public static void testToString(){
        Card c1 = new Card("10","Hearts");
        Card c2 = new Card("10","Diamonds");
        Card c3 = new Card("8","Hearts");
        Card c4 = new Card("8","Hearts");
        Card c5 = new Card("3","Hearts");
        ArrayList<Card> array1 = new ArrayList<>();
        array1.add(c1);
        array1.add(c2);
        array1.add(c3);
        array1.add(c4);
        array1.add(c5);
        PokerHand hand1 = new PokerHand(array1);

        Testing.assertEquals("Tests toString for the pokerhand"
                , "[10 of Hearts, 10 of Diamonds, 8 of Hearts, 8 of Hearts, 3 of Hearts]"
                , hand1.toString());
    }

    public static void testAddCard(){
        Card d1 = new Card(14,3);
        Card d2 = new Card(12,3);
        Card d3 = new Card(9,3);
        Card d4 = new Card(9,3);
        Card d5 = new Card(13,3);
        ArrayList<Card> array2 = new ArrayList<>();
        PokerHand hand2 = new PokerHand(array2);
        hand2.addCard(d1);
        hand2.addCard(d2);
        hand2.addCard(d3);
        hand2.addCard(d4);
        hand2.addCard(d5);

        Testing.assertEquals("Tests 2 flushes for the 2nd highest card"
                , "[Ace of Diamonds, Queen of Diamonds, 9 of Diamonds, 9 of Diamonds, King of Diamonds]"
                , hand2.toString());
    }

}

