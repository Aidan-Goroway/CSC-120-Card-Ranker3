package proj4;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class Deck {

    private final int[] RANKS = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};
    private final int[] SUITS = {0,1,2,3};
    private final int MAX_CARDS_IN_DECK = 52;

    private ArrayList<Card> cardDeck;
    private int nextToDeal;

    /**
     *constructor. Makes a deck of 52 playing cards
     */
    public Deck(){

        this.cardDeck = new ArrayList<>(MAX_CARDS_IN_DECK);
        this.nextToDeal = 0;

        for (int rankIndex=0; rankIndex<RANKS.length; rankIndex++){
            for(char suitIndex=0; suitIndex<SUITS.length; suitIndex++){
                cardDeck.add( new Card(RANKS[rankIndex],SUITS[suitIndex]) );
            }
        }
    }

    /**
     * Shuffles the Deck. Only shuffles cards that have NOT been dealt.
     */
    public void shuffle(){
        for (int cardIndex=0; cardIndex<cardDeck.size(); cardIndex++){
            int randomIndex = ThreadLocalRandom.current().nextInt(nextToDeal,MAX_CARDS_IN_DECK);
            cardDeck = swap(cardDeck, cardIndex, randomIndex);

        }
    }

    /**
     * A method to swap all the undealt cards in a deck.
     * @param list an ArrayList of <Card> type</Card>
     * @param currentIndicy the indicy of the current card in our loop
     * @param randomIndicy the indicy of a random undealt card in the deck
     * @return returns a swapped ArrayList (specifically a swapped deck)
     */
    private ArrayList<Card> swap(ArrayList<Card> list, int currentIndicy, int randomIndicy){

        Card temp1;
        Card temp2;

        temp1 = list.get(currentIndicy);
        temp2 = list.get(randomIndicy);

        list.set(currentIndicy,temp2);
        list.set(randomIndicy, temp1);

        return list;
    }

    /**
     * Deals a card, or returns nothing if the deck is empty.
     * @return Returns a card, or null the deck is empty.
     */
    public Card deal(){
        nextToDeal++;
        if(cardDeck.size() > 0) {
            return cardDeck.get(nextToDeal - 1);
        }
        else{
            return null;
        }
    }

    /**
     * Determines if there are cards left to deal in the deck.
     * @return true or false, depending on if the deck has cards left to deal.
     */
    public boolean isEmpty() {
        if ((MAX_CARDS_IN_DECK - nextToDeal) > 0) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Determines how many cards in the deck have not been dealt yet.
     * @return integer number of cards not yet dealt.
     */
    public int size(){
        return (MAX_CARDS_IN_DECK - nextToDeal);
    }

    /**
     * Returns the deck to a state where no cards have been dealt
     */
    public void gather(){
        nextToDeal = 0;
    }

    /**
     * Returns all undealt cards remaining in the deck
     * @return An easily readable string of all the undealt cards in the deck.
     */
    public String toString(){

        ArrayList<Card> undealtList = new ArrayList<>();

        for (int card=nextToDeal; card<cardDeck.size(); card++){
            undealtList.add( cardDeck.get(card) );
        }

        return undealtList.toString();
    }

}
