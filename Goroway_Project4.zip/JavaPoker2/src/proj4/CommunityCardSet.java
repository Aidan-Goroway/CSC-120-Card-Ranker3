package proj4;

import java.util.ArrayList;

public class CommunityCardSet {

    private final int MAX_CARDS_IN_HAND = 5;
    private ArrayList<Card> cCards;

    /**
     * Constructor.
     * @param cCards An arrayList of community cards
     * any hand can make use of.
     */
    public CommunityCardSet(ArrayList<Card> cCards){
        this.cCards = cCards;
    }

    /**
     * Adds a card to the cCard Set.
     * If the set is full, does nothing.
     * @param CardObject The card that will be added.
     */
    public void addCard(Card CardObject){

        if (cCards.size() <= MAX_CARDS_IN_HAND){
            cCards.add(CardObject);
        }
        else {
            return;
        }
    }

    /**
     * Returns a card from the set.
     * @param index The index of the card we are getting.
     * @return returns the card at the specified index.
     * If the index is invalid, returns nothing at all.
     */
    public Card get_ith_card(int index){

        if ((index >= 0) || (index < MAX_CARDS_IN_HAND)){
            return cCards.get(index);
        }
        else {
            return null;
        }
    }

    /**
     * Returns all the cards in the communityCard set.
     * @return Returns an easily readable string of all the cards in the set.
     */
    public String toString(){

        ArrayList<Card> handList = new ArrayList<>();
        for (int card=0; card<cCards.size(); card++){
            handList.add( cCards.get(card) );
        }
        return handList.toString();
    }

}
